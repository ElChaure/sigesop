-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 28-06-2012 a las 09:54:02
-- Versión del servidor: 5.1.33
-- Versión de PHP: 5.2.9-2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `sigesop`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dependencias`
--

CREATE TABLE IF NOT EXISTS `dependencias` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `dependencia` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `ubicacion` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `responsable` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `celular` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `local` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `condicion` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=80 ;

--
-- Volcar la base de datos para la tabla `dependencias`
--

INSERT INTO `dependencias` (`id`, `dependencia`, `ubicacion`, `responsable`, `celular`, `local`, `condicion`) VALUES
(1, 'Administración  y Finanzas', 'Piso 3', 'Lic. Carlos Contreras', '(0414)-137-81-89 (0426)-512-60-26', '(0212)-451-22-14', 1),
(2, 'Almacén ', 'Sótano 2', 'William Badillo', '(0414)-319-44-25 (0416)-610-19-05 ', '', 1),
(3, 'Archivo', 'Piso 5', 'Lic. María Zamudio', '(0426)-514-03-34', '451-12-46', 1),
(4, 'Archivo Pasivo', 'Sótano 2', 'Lic. María Zamudio', '(0426)-514-03-34', '', 1),
(5, 'Asesoría Legal', 'Piso 8', 'Abg. Carmen Elena Granado', '(0414)-196-83-22', '(0212)-461-32-17', 1),
(6, 'Atencion al Soberano', 'piso 2', 'Osner Becerra             Elvira Díaz', '(0412)-576-87-05 (0414)-231-45-69', '(0212)-461-10-46', 1),
(7, 'Barrio Adentro', 'Piso 4', 'Dr. Mario Laya', '(0426)-514-08-55', '(0212)-461-60-04', 1),
(8, 'Bienes Nacionales', 'Piso 3', 'Lic. Manuel  Rodríguez', '(0424)-267-83-91', '(0212)-451-56-19', 1),
(9, 'Bienestar Social ', 'Piso 8', '', '', '(0212)-461-16-51', 1),
(10, 'Bioanalisis', 'Piso 4', 'Lic. Néstor de Luca', '(0424)-187-33-34', '(0212)-461-50-86', 1),
(11, 'Caja', 'Planta Baja', 'Rafael Pérez', '(0412)-903-16-38', '(0212)-462-38-14', 1),
(12, 'Capacitación y Desarrollo del Talento Humano', 'Piso 2', '', '', '(0212)-451-62-52', 1),
(13, 'Clasificación y Remuneración', 'Piso 7 ', '', '', '(0212)-461-34-42', 1),
(14, 'Colegio de Enfemería', 'Piso 2', 'Lic. Comoroto Valera', '(0424)-248-69-90 (0412)-025-20-01', '(0212)-636-68-61', 1),
(15, 'Compras', 'Piso 3 ', 'Lic. Henry Serrano', '(0414)-227-91-77', '(0212)-451-38-19', 1),
(16, 'Contabilidad', 'Piso 3', 'Lic. Pedro Fitzallen', '(0414)-321-90-46', '(0212)-880-48-23 (0212)-275-32-87', 1),
(17, 'Control Interno', 'Piso 3', '', '', '(0212)-275-18-46', 1),
(18, 'Control de Gestión', 'Piso 8', 'Dra. Yaneth León', '(0426)-520-95-44', '(0212)-415-79-15', 1),
(19, 'Correspondencia', 'Piso 4', 'Rafael Henríquez', '(0414)-214-19-02', '', 1),
(20, 'Despacho', ' Planta Baja', 'Dr. Jairo Silva ', '(0416)-822-80-22', '(0212)-451-44-17', 1),
(21, 'Deudas', 'Piso 3', 'Lic. Karina Canelón', '(0414)-238-47-24', '(0212)-461-60-81', 1),
(22, 'Distritos Sanitarios y Ambularios', 'Piso 6', 'Dr. Guerman Porras', '(0416)-814-66-31', '(0212)-461-51-01', 1),
(23, 'Docencia e Investigación', 'Piso 2', 'Dr. Jairo Silva               Zuly Cordova', '(0416)-822-80-27 (0412)-909-08-07', '(0212)-451-62-52', 1),
(24, 'Enfermería', 'Piso 6', 'Lic. Rosa Suarez', '(0414)-288-64-48', '(0212)-451-00-98 Ext. 52131', 1),
(25, 'Farmacia', 'Sótano 2', 'Dra. Ana Echenique', '(0416)-822-82-31', '(0212)-461-20-97 (0212)-451-17-58', 1),
(26, 'Finanzas', 'Piso 3', '', '', '(0212)-462-70-51', 1),
(27, 'Gestión y Control', '', 'Lic. Yaneth León', '', '(0212)-415-79-15', 1),
(28, 'Hospitales', 'Piso 4', 'Dr. Jairo Silva', '(0416)-822-80-27', '(0212)-462-32-44', 1),
(29, 'I.S.L.R.', 'Piso 3', 'Álvaro González', '(0414)-339-57-20', '(0212)-615-94-05', 1),
(30, 'Informática ', 'Piso 7 ', 'Lic. Zoila Paris', '(0416)-604-22-01', '(0212)-451-59-14', 1),
(31, 'Jubilaciones, Penciones y Prestaciones Sociales', 'Piso 5', 'Lic. Xiomara Mendoza', '(0414)-018-40-24', '(0212)-461-51-52', 1),
(32, 'Mantenimiento', 'Piso 8', 'Magda Morales', '(0414)-131-30-93', '(0212)-461-42-69', 1),
(33, 'Misiones', 'Piso 2 ', 'Mary Tacoa', '(0416)-403-34-80', '(0212)-582-47-17', 1),
(34, 'Nómina ', 'Piso 5', 'Lic. Rosiris Bonilla', '', '(0212)-461-18-30', 1),
(35, 'Participación Social y Ciudadana', 'Piso 4', 'Osner Becerra        ', '(0412)-576-87-05', '(0212)-451-92-07', 1),
(36, 'Planificación ', 'Piso 7 ', '', '', '(0212)-461-20-04', 1),
(37, 'Presupuesto', 'Piso 7 ', 'Hétor Pérez', '(0416)-724-49-66', '(0212)-451-71-64', 1),
(38, 'Prensa', 'Planta Baja', 'Lic. Mary Carmen Arias', '(0414)-207-91-31', '(0212)-451-44-17', 1),
(39, 'Prestaciones Sociales ', 'Piso 5', '', '', '(0212)-834-49-69', 1),
(40, 'Prevención de Riesgo y Atención de Emergencias y Desastres ', 'Planta Baja', 'Dr. Sergio López', '', '(0212)-451-44-17', 1),
(41, 'Promoción para la Salud', 'Piso 6 ', 'Antropólogo Yoni Smith', '(0416)-830-63-55', '(0212)-583-59-50', 1),
(42, 'Proyectos Especiales ', ' Piso 7', '', '', '(0212)-461-33-66', 1),
(43, 'Rayos X e Imagenologia', 'Piso 6', 'Lic. Zulay Fajardo', '(0414)-268-05-36', '(0212)-451-51-01', 1),
(44, 'Reclutamiento y Selección', 'Piso 8 ', '', '', '(0212)-462-22-29', 1),
(45, 'Recursos Humanos', 'Piso 6', '', '', '(0212)-461-23-08', 1),
(46, 'Registro y Control', 'Piso 7 ', '', '', '(0212)-461-40-95', 1),
(47, 'Rehabilitación ', 'Piso 4', 'Dr. Rafael Rojas', '(0426)-511-55-93', '', 1),
(48, 'Relaciones Interinstitucionales', 'Piso 7 ', 'Alejandro Serrano', '(0412)-631-53-84', '(0212)-461-33-66', 1),
(49, 'Reproducción ', 'Piso7', 'Efrén Jiménez', '(0412)-028-21-53', '(0212)-451-59-14', 1),
(50, 'Salud Bucal ', 'Piso6', 'Dra. Elvira Rosas', '(0414)-130-36-65', '(0212)-490-17-37', 1),
(51, 'Salud Mental', 'Piso 4', 'Dr. Angel Riera', '', '(0212)-461-34-17', 1),
(52, 'Seguridad', 'Planta Baja', '', '', '(0212)-451-11-50', 1),
(53, 'SIAMU', 'Piso 6', 'Cnel. Néstor Rubio', '(0416)-610-12-95', '(0212)-451-00-98', 1),
(54, 'Transporte', 'Sótano 2', '', '', '(0212)-451-44-17 Ext. 24', 1),
(55, 'Hosp. Vargas de Caracas', '', '', '', '', 2),
(56, 'Hosp. Ricardo Baquero Gonzalez', '', '', '', '', 2),
(57, 'Hosp. Psiquiatrico de Caracas', '', '', '', '', 2),
(58, 'Hosp. Maternidad Concepcion Palacios', '', '', '', '', 2),
(59, 'Hosp. Julio Criollo Rivas', '', '', '', '', 2),
(60, 'Centro de Orientacion Las Palmas', '', '', '', '', 2),
(61, 'Hosp. Jose Ignacio Baldo', '', '', '', '', 2),
(62, 'Hosp. Dr. Jesus Yerena', '', '', '', '', 2),
(63, 'Hosp. Infantil JM de los Rios', '', '', '', '', 2),
(64, 'Hosp. Oncologico Dr.Luis Razetti', '', '', '', '', 2),
(65, 'Hosp. Municipal del Junquito', '', '', '', '', 2),
(66, 'Hosp. Dr.Jose Gregorio Hernandez', '', '', '', '', 2),
(67, 'Hosp. Dr.Francisco Antonio Risquez', '', '', '', '', 2),
(68, 'Hosp. Dr.Leopoldo Manrique Terrero', '', '', '', '', 2),
(69, 'Hosp. Materno Infantil de Caricuao', '', '', '', '', 2),
(70, 'Centro de Orientacion Las Palmas', '', '', '', '', 2),
(71, 'La Ciudadela', '', '', '', '', 2),
(72, 'Secretaria de Salud', '', '', '', '', 2),
(73, 'Servicio Medico Alcaldia DTTO 3', '', '', '', '', 2),
(74, 'Distrito 1', '', '', '', '', 2),
(75, 'Distrito 2', '', '', '', '', 2),
(76, 'Distrito 3', '', '', '', '', 2),
(77, 'Distrito 4', '', '', '', '', 2),
(78, 'Hosp. Miguel Perez de Leon', '', '', '', '', 2),
(79, 'Amb. Humberto Fernandez Moran', '', '', '', '', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `especialidades`
--

CREATE TABLE IF NOT EXISTS `especialidades` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `especialidad` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Volcar la base de datos para la tabla `especialidades`
--

INSERT INTO `especialidades` (`id`, `especialidad`) VALUES
(1, 'Soporte en Hardware y/o Software'),
(2, 'Soporte en Redes'),
(3, 'Soporte en Telefonia'),
(4, 'Soporte en Servidores y/o Telecomunicaciones'),
(5, 'Desarrollo de Sistemas / Bases de Datos'),
(6, 'Organizacion y Sistemas'),
(7, 'Carnetizacion');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estatus`
--

CREATE TABLE IF NOT EXISTS `estatus` (
  `id` int(2) NOT NULL,
  `nombre` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcar la base de datos para la tabla `estatus`
--

INSERT INTO `estatus` (`id`, `nombre`) VALUES
(1, 'Pendiente'),
(2, 'Finalizado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fechas`
--

CREATE TABLE IF NOT EXISTS `fechas` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `desde` date NOT NULL,
  `hasta` date NOT NULL,
  `tecnico_id` int(4) NOT NULL,
  `dependencia_id` int(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `fechas`
--

INSERT INTO `fechas` (`id`, `desde`, `hasta`, `tecnico_id`, `dependencia_id`) VALUES
(1, '2011-07-01', '2011-08-05', 1, 1),
(2, '2011-07-01', '2011-08-05', 1, 1),
(3, '2011-07-01', '2011-08-05', 5, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `solicitudes`
--

CREATE TABLE IF NOT EXISTS `solicitudes` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  `receptor_id` int(4) NOT NULL,
  `dependencia_id` int(4) NOT NULL,
  `usuario` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cpu` int(1) DEFAULT '0',
  `impresora` int(1) DEFAULT '0',
  `mouse` int(1) DEFAULT '0',
  `teclado` int(1) DEFAULT '0',
  `escaner` int(1) DEFAULT '0',
  `monitor` int(1) DEFAULT '0',
  `telecom` int(1) DEFAULT '0',
  `otro1` int(1) DEFAULT '0',
  `serial` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bien_nacional` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `modelo` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hardware` int(1) DEFAULT '0',
  `software` int(1) DEFAULT '0',
  `mantenimiento` int(1) DEFAULT '0',
  `antivirus` int(1) DEFAULT '0',
  `red` int(1) DEFAULT '0',
  `otro2` int(1) DEFAULT '0',
  `motivo` text COLLATE utf8_unicode_ci NOT NULL,
  `tecnico_id` int(4) NOT NULL,
  `observaciones` text COLLATE utf8_unicode_ci,
  `estatus` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `receptor_ind` (`receptor_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `solicitudes`
--

INSERT INTO `solicitudes` (`id`, `fecha`, `hora`, `receptor_id`, `dependencia_id`, `usuario`, `cpu`, `impresora`, `mouse`, `teclado`, `escaner`, `monitor`, `telecom`, `otro1`, `serial`, `bien_nacional`, `modelo`, `hardware`, `software`, `mantenimiento`, `antivirus`, `red`, `otro2`, `motivo`, `tecnico_id`, `observaciones`, `estatus`) VALUES
(1, '2011-11-10', '10:00:00', 15, 46, 'Teresa Contreras', 0, 0, 0, 0, 0, 0, 0, 1, '', '', '', 0, 1, 0, 0, 0, 0, 'Solicitud de Sistema para el control de los expedientes recibidos', 12, 'En Proceso', 1),
(2, '2012-06-21', '15:21:00', 15, 7, 'Pedro Perez', 1, 0, 0, 1, 0, 0, 1, 0, '', '', '', 1, 0, 0, 0, 1, 0, 'sdfsdfsdfsdfsdf', 5, 'asj asñklj ñlkjas ñkljasljk', 2),
(3, '2012-06-21', '15:47:00', 15, 1, 'rtyretyrtytry', 1, 0, 1, 0, 0, 1, 0, 0, '', '', '', 0, 0, 0, 0, 0, 0, 'try tryty tryrty', 7, '', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tecnicos`
--

CREATE TABLE IF NOT EXISTS `tecnicos` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `nombre_tecnico` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `especialidad_id` int(1) NOT NULL,
  `username` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `usr_tipo` int(1) NOT NULL,
  `estatus` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=16 ;

--
-- Volcar la base de datos para la tabla `tecnicos`
--

INSERT INTO `tecnicos` (`id`, `nombre_tecnico`, `especialidad_id`, `username`, `password`, `email`, `usr_tipo`, `estatus`) VALUES
(1, 'Alexander Avila', 1, 'aavila', '123456', '', 2, 'Activo'),
(2, 'Edwin Rojas', 1, 'erojas', '123456', NULL, 1, 'Activo'),
(3, 'Eribeth Duran', 1, 'eduran', '123456', NULL, 0, 'Activo'),
(4, 'Francisco Leopardi', 1, 'fleopardi', '123456', NULL, 2, 'Activo'),
(5, 'Freddy Gil', 1, 'fgil', '123456', NULL, 2, 'Activo'),
(6, 'Jenifer Charles', 1, 'jcharles', '123456', NULL, 3, 'Activo'),
(7, 'Joonathan Pino', 1, 'jpino', '123456', NULL, 2, 'Activo'),
(8, 'Julio Berroteran', 1, 'jberroteran', '123456', NULL, 2, 'Activo'),
(9, 'Victor Messuti', 1, 'vmessuti', '123456', NULL, 2, 'Activo'),
(10, 'Sherlley Castro', 1, 'scastro', '123456', NULL, 2, 'Activo'),
(11, 'Gretty Cordero', 1, 'gcordero', '123456', NULL, 2, 'Activo'),
(12, 'Luis Almaro', 1, 'lalmaros', 'l9098342', NULL, 0, 'Activo'),
(13, 'Zoila Paris', 1, 'zparis', '123456', NULL, 0, 'Activo'),
(14, 'Wilfredo Anis', 1, 'wanis', '123456', '', 0, 'Activo'),
(15, 'Alejandra Barroso', 7, 'abarroso', '123456', '', 3, 'Activo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `valores`
--

CREATE TABLE IF NOT EXISTS `valores` (
  `id` int(3) NOT NULL,
  `valor` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcar la base de datos para la tabla `valores`
--

INSERT INTO `valores` (`id`, `valor`) VALUES
(0, 'N/A'),
(1, 'Presenta Fallas');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `valores2`
--

CREATE TABLE IF NOT EXISTS `valores2` (
  `id` int(3) NOT NULL,
  `valor` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcar la base de datos para la tabla `valores2`
--

INSERT INTO `valores2` (`id`, `valor`) VALUES
(0, 'N/A'),
(1, 'Revisado / Reparado');

--
-- Filtros para las tablas descargadas (dump)
--

--
-- Filtros para la tabla `solicitudes`
--
ALTER TABLE `solicitudes`
  ADD CONSTRAINT `solicitudes_ibfk_1` FOREIGN KEY (`receptor_id`) REFERENCES `tecnicos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
